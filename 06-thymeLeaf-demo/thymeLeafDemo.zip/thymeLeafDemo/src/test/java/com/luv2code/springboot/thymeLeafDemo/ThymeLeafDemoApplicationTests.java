package com.luv2code.springboot.thymeLeafDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeLeafDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
